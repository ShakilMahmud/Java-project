
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class javaconnect {
 Connection conn;
 public static Connection ConnecrDb(){
     try
        {
            com.mysql.jdbc.Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost/librarybd1","root","");
           return conn;     
        } 
        catch (ClassNotFoundException  | SQLException ex) 
        {
            Logger.getLogger(javaconnect.class.getName()).log(Level.SEVERE, null, ex);
         return null;
        }  
 }
}
